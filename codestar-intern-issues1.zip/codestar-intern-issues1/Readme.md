# Issues Repo!

This repo is used just for interns' issues, don't push code & documents please!

Here you can do one of following:
* [Start a new phase](https://github.com/Star-Academy/codestar-intern-issues/issues/new/choose)
* [Check open issues](https://github.com/Star-Academy/codestar-intern-issues/issues)
* [Documents repo](https://github.com/Star-Academy/codestar-internship)
