---
name: Front End - Phase 01
about: This issue template is based of PhaseF01-HTML contents.
title: FE-Phase01-Team[TEAM_NUMBER_HERE]
labels: [FE]
assignees: ''

---

- [ ] Introduction
- [ ] Learning
  - [ ] Semantic Elements
  - [ ] Text Formatting Elements
  - [ ] Images
- [ ] Project
  - [ ] Landing
  - [ ] Signup
  - [ ] Login
  - [ ] Songs List
  - [ ] Playlist
  - [ ] Song
