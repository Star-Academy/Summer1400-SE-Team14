---
name: Front End - Phase 03
about: This issue template is based of PhaseF03-SCSS contents.
title: FE-Phase03-Team[TEAM_NUMBER_HERE]
labels: [FE]
assignees: ''

---

- [ ] Introduction
- [ ] Setup
  - [ ] Node.js
  - [ ] SASS
- [ ] Learning
  - [ ] Nested Selectors
  - [ ] Variables
  - [ ] Mixins
- [ ] Project
  - [ ] Landing
  - [ ] Signup
  - [ ] Login
  - [ ] Songs List
  - [ ] Playlist
  - [ ] Song
