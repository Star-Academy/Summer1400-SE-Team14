---
name: Software Engineering - Phase 08
about: This issue template is based of Phase08-EFCore contents.
title: SE-Phase08-Team[TEAM_NUMBER_HERE]
labels: [SE]
assignees: ''

---

- [ ] Implement Past project with EfCore in C#

### Review

Link of your own PR:

`[FILL HERE WITH LINK OF YOUR PR.]`

Link of other PR(s) you agreed to review:

`[FILL HERE WITH LINK OF PR(s) YOU REVIEWED.]`


- [ ] Your own PR is reviewed and approved by at least one other team.

- [ ] Your own PR is reviewed and approved by mentor (mentor 2).

- [ ] Your own PR is reviewed and approved by manager (mentor 1).

- [ ] Your own PR is merged.
