---
name: Front End - Phase 04
about: This issue template is based of PhaseF04-JavaScript contents.
title: FE-Phase04-Team[TEAM_NUMBER_HERE]
labels: [FE]
assignees: ''

---

- [ ] Introduction
- [ ] Learning
  - [ ] Variables
  - [ ] Regular Function vs Arrow Function
- [ ] Project
