---
name: Front End - Phase 02
about: This issue template is based of PhaseF02-CSS contents.
title: FE-Phase02-Team[TEAM_NUMBER_HERE]
labels: [FE]
assignees: ''

---

- [ ] Introduction
- [ ] Learning
  - [ ] Box Model
  - [ ] Units
  - [ ] Selectors
